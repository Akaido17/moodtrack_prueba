// server.js - Archivo principal del servidor
const express = require('express');
const cors = require('cors');
const { Pool } = require('pg');
require('dotenv').config();


// Crear la aplicación Express
const app = express();
const puerto = 3000;

// Configuración de la base de datos PostgreSQL
// CAMBIA ESTOS DATOS POR LOS TUYOS
const baseDatos = new Pool({
  user: 'postgres',        // Tu usuario de PostgreSQL
  host: 'localhost',       // Donde está tu PostgreSQL (localhost si es local)
  database: 'postgres',     // Nombre de tu base de datos
  password: 'admin123', // Tu contraseña de PostgreSQL
  port: 5432,             // Puerto de PostgreSQL (5432 por defecto)
});

// Configurar middlewares (cosas que se ejecutan antes de las rutas)
app.use(cors()); // Permite que Flutter se conecte
app.use(express.json()); // Permite recibir JSON

// RUTA PRINCIPAL - Para probar que funciona
app.get('/', (req, res) => {
  res.json({ 
    mensaje: '¡Servidor funcionando!', 
    fecha: new Date().toLocaleString() 
  });
});

// RUTA PARA REGISTRO DE USUARIOS
app.post('/api/register', async (req, res) => {
  console.log('═══════════════════════════════════');
  console.log('📨 Petición recibida en /api/register');
  console.log('📦 Body completo:', req.body);
  
  const { usuario, password } = req.body;
  
  console.log('📧 Usuario extraído:', usuario);
  console.log('🔑 Password extraído:', password ? '***' : 'vacío');
  
  // Validar que los campos no estén vacíos
  if (!usuario || !password) {
    console.log('❌ Faltan datos');
    return res.status(400).json({ 
      error: 'Usuario y contraseña son obligatorios' 
    });
  }

  // Validar longitud de contraseña
  if (password.length < 6) {
    console.log('❌ Contraseña muy corta');
    return res.status(400).json({ 
      error: 'La contraseña debe tener al menos 6 caracteres' 
    });
  }
  
  try {
    console.log('🔍 Verificando si el usuario ya existe...');
    
    // Verificar si el usuario ya existe
    const usuarioExistente = await baseDatos.query(`
      SELECT usuario 
      FROM usuarios 
      WHERE usuario = $1
    `, [usuario]);
    
    if (usuarioExistente.rows.length > 0) {
      console.log('❌ El usuario ya está registrado');
      return res.status(409).json({ 
        error: 'Este correo electrónico ya está registrado' 
      });
    }
    
    console.log('💾 Insertando nuevo usuario en la base de datos...');
    
    // Insertar el nuevo usuario
    const resultado = await baseDatos.query(`
      INSERT INTO usuarios (usuario, password) 
      VALUES ($1, $2) 
      RETURNING usuario, password
    `, [usuario, password]);
    
    const nuevoUsuario = resultado.rows[0];
    console.log('✅ Usuario registrado exitosamente:', nuevoUsuario.usuario);
    
    const respuesta = {
      success: true,
      mensaje: 'Usuario registrado exitosamente',
      usuario: {
        usuario: nuevoUsuario.usuario
      }
    };
    
    console.log('📤 Enviando respuesta:', JSON.stringify(respuesta));
    console.log('═══════════════════════════════════');
    
    res.status(201).json(respuesta);
    
  } catch (error) {
    console.error('❌ Error en registro:', error.message);
    console.log('═══════════════════════════════════');
    res.status(500).json({ 
      error: 'Error en el servidor',
      detalle: error.message 
    });
  }
});

// RUTA PARA LOGIN - Agregar ANTES de app.listen()
app.post('/api/login', async (req, res) => {
  console.log('═══════════════════════════════════');
  console.log('📨 Petición recibida en /api/login');
  console.log('📦 Body completo:', req.body);
  
  const { usuario, password } = req.body;
  
  
  console.log('📧 Usuario extraído:', usuario);
  console.log('🔑 Password extraído:', password ? '***' : 'vacío');
  
  if (!usuario || !password) {
    console.log('❌ Faltan datos');
    return res.status(400).json({ 
      error: 'Usuario y contraseña son obligatorios' 
    });
  }
  
  try {
    console.log('🔍 Buscando en base de datos...');
    
    const resultado = await baseDatos.query(`
      SELECT usuario,password 
      FROM usuarios 
      WHERE usuario = $1 AND password = $2
    `, [usuario, password]);
    
    console.log('📊 Registros encontrados:', resultado.rows.length);
    
    if (resultado.rows.length === 0) {
      console.log('❌ Credenciales incorrectas');
      return res.status(401).json({ 
        error: 'Credenciales incorrectas' 
      });
    }
    
    const usuarioData = resultado.rows[0];
    console.log('✅ Login exitoso:', usuarioData.email);

    
    const respuesta = {
      success: true,
      usuario: {
        id: usuarioData.id,
        email: usuarioData.email,
        nombre: usuarioData.nombre
      }
    };
    
    console.log('📤 Enviando respuesta:', JSON.stringify(respuesta));
    console.log('═══════════════════════════════════');
    
    res.json(respuesta);
    
  } catch (error) {
    console.error('❌ Error en login:', error.message);
    console.log('═══════════════════════════════════');
    res.status(500).json({ 
      error: 'Error en el servidor',
      detalle: error.message 
    });
  }
});

// INICIAR EL SERVIDOR - Debe estar AL FINAL
app.listen(puerto, () => {
  // ...
});

// RUTA PARA OBTENER TODOS LOS REGISTROS
app.get('/api/registros', async (req, res) => {
  console.log('📋 Solicitando todos los registros...');
  
  try {
    // Hacer consulta a PostgreSQL
    const resultado = await baseDatos.query(`
      SELECT  codigo,nombre,especialidad,nro_registro 
      FROM psicologos
      ORDER BY codigo DESC
    `);
    
    console.log(`✅ Encontrados ${resultado.rows.length} registros`);
    
    // Enviar los datos a Flutter
    res.json(resultado.rows);
    
  } catch (error) {
    console.error('❌ Error al obtener registros:', error.message);
    
    res.status(500).json({ 
      error: 'No se pudieron obtener los registros',
      detalle: error.message 
    });
  }
});


app.post('/api/estados-animo', async (req, res) => {
  console.log('💭 Guardando estado de ánimo...');
  console.log('📦 Body:', req.body);
  
  const { codigo, estado,comentario } = req.body;
  
  // Validar datos obligatorios
 // if (!codigo || !nivel) {
 //   return res.status(400).json({ 
 //     error: 'usuarioid y nivel son obligatorios' 
 //   });
 // }
  
  try {
    const resultado = await baseDatos.query(`
      INSERT INTO estados (codigo, estado, comentario) 
      VALUES ($1, $2, $3) 
      RETURNING *
    `, [codigo, estado,comentario]);
    
    console.log('✅ Estado de ánimo guardado:', resultado.rows[0].id);
    
    res.status(201).json({
      success: true,
      data: resultado.rows[0]
    });
    
  } catch (error) {
    console.log('Fallo');
  console.error('❌ Error al guardar estado de ánimo:', error); 
  res.status(500).json({ 
    error: 'Error al guardar',
    detalle: error.message 
  });
}
});

// RUTA PARA OBTENER ESTADOS DE ÁNIMO DE UN USUARIO
app.get('/api/estados-animo/:usuarioid', async (req, res) => {
  const { usuarioid } = req.params;
  
  console.log('📋 Obteniendo estados de ánimo del usuario:', usuarioid);
  
  try {
    const resultado = await baseDatos.query(`
      SELECT * FROM estados
      WHERE codigo = $1 
    `, [usuarioid]);
    
    console.log('✅ Encontrados:', resultado.rows.length, 'registros');
    
    res.json({
      success: true,
      data: resultado.rows
    });
    
  } catch (error) {
    console.log('Fallo');
  // 💡 DETALLE COMPLETO DEL ERROR DE LA DB
  console.error('❌ Error al guardar estado de ánimo:', error); 
  res.status(500).json({ 
    error: 'Error al guardar',
    detalle: error.message 
  });
}
});

// RUTA PARA ACTUALIZAR UN REGISTRO
app.put('/api/registros/:id', async (req, res) => {
  const id = req.params.id;
  const { nombre, estado } = req.body;
  
  console.log(`📝 Actualizando registro ${id}:`, { nombre, estado });
  
  try {
    const resultado = await baseDatos.query(`
      UPDATE registros 
      SET nombre = $1, estado = $2 
      WHERE id = $3 
      RETURNING *
    `, [nombre, estado, id]);
    
    if (resultado.rows.length === 0) {
      return res.status(404).json({ error: 'Registro no encontrado' });
    }
    
    console.log('✅ Registro actualizado');
    res.json(resultado.rows[0]);
    
  } catch (error) {
    console.error('❌ Error al actualizar registro:', error.message);
    
    res.status(500).json({ 
      error: 'No se pudo actualizar el registro',
      detalle: error.message 
    });
  }
});

// RUTA PARA ELIMINAR UN REGISTRO
app.delete('/api/registros/:id', async (req, res) => {
  const id = req.params.id;
  
  console.log(`🗑️ Eliminando registro ${id}`);
  
  try {
    const resultado = await baseDatos.query(`
      DELETE FROM registros 
      WHERE id = $1 
      RETURNING *
    `, [id]);
    
    if (resultado.rows.length === 0) {
      return res.status(404).json({ error: 'Registro no encontrado' });
    }
    
    console.log('✅ Registro eliminado');
    res.json({ mensaje: 'Registro eliminado correctamente' });
    
  } catch (error) {
    console.error('❌ Error al eliminar registro:', error.message);
    
    res.status(500).json({ 
      error: 'No se pudo eliminar el registro',
      detalle: error.message 
    });
  }
});

// PROBAR CONEXIÓN A LA BASE DE DATOS
async function probarConexion() {
  try {
    const resultado = await baseDatos.query('SELECT NOW()');
    console.log('✅ Conexión a PostgreSQL exitosa:', resultado.rows[0].now);
  } catch (error) {
    console.error('❌ Error conectando a PostgreSQL:', error.message);
    console.log('💡 Verifica que PostgreSQL esté ejecutándose y que las credenciales sean correctas');
  }
}

// INICIAR EL SERVIDOR
app.listen(puerto, () => {
  console.log('🚀 ================================');
  console.log(`🚀 Servidor iniciado en puerto ${puerto}`);
  console.log(`🚀 Prueba en: http://localhost:${puerto}`);
  console.log(`🚀 API registros: http://localhost:${puerto}/api/registros`);
  console.log(`pr`);
  console.log('🚀 ================================');
  
  // Probar conexión a la base de datos
  probarConexion();
});

// MANEJO DE CIERRE GRACEFUL
process.on('SIGINT', async () => {
  console.log('\n🛑 Cerrando servidor...');
  await baseDatos.end();
  console.log('✅ Conexiones cerradas');
  process.exit(0);
});