import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:lib/Pantallas/PantallaEstadoAnimo.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path/path.dart' as path_package;
import 'package:sqflite/sqflite.dart';
import 'dart:io';
import 'Pantalla_login.dart';
import 'Pantalla_registro.dart';
import 'package:http/http.dart' as http;
import 'Pantalla_Objetivos.dart';
import '../Recordatorio.dart';
import '../servicios/db_helper.dart';

class PantallaRecordatorios extends StatelessWidget {
  final List<Recordatorio> recordatorios;
  final Function(Recordatorio) alAgregarRecordatorio;
  final Function(int) alAlternarRecordatorio;
  final bool cargando;
  final Future<void> Function()? onRefresh;

  PantallaRecordatorios({
    required this.recordatorios,
    required this.alAgregarRecordatorio,
    required this.alAlternarRecordatorio,
    this.cargando = false,
    this.onRefresh,
  });

  final List<String> nombresDiasSemana = [
    'Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Recordatorios',
            style: TextStyle(fontSize: 24, color: Colors.white , fontWeight: FontWeight.bold)
        ),
        backgroundColor: Colors.black,
        actions: [
          IconButton(
            icon: Icon(Icons.bug_report),
            onPressed: () {
              print('🐛 DEBUG - Recordatorios en pantalla: ${recordatorios.length}');
              for (var rec in recordatorios) {
                print('  - ${rec.titulo} (ID: ${rec.id})');
              }
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Debug: ${recordatorios.length} recordatorios en pantalla')),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: () {
              print('🔄 Forzando recarga de recordatorios...');
              onRefresh?.call();
            },
          ),
        ],
      ),
      body: cargando
          ? Center(child: CircularProgressIndicator())
          : recordatorios.isEmpty
              ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.notifications_off, size: 80, color: Colors.grey),
            Text(
              'No tienes recordatorios aún',
              style: TextStyle(fontSize: 18, color: Colors.grey),
            ),
          ],
        ),
      )
              : RefreshIndicator(
        onRefresh: onRefresh ?? () async {},
        child: ListView.builder(
          itemCount: recordatorios.length,
          itemBuilder: (context, indice) {
            final recordatorio = recordatorios[indice];
            return Card(
              margin: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: ListTile(
                leading: Icon(
                  recordatorio.estaActivo ? Icons.notifications_active : Icons.notifications_off,
                  color: recordatorio.estaActivo ? Colors.purple : Colors.grey,
                ),
                title: Text(recordatorio.titulo),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (recordatorio.descripcion.isNotEmpty) Text(recordatorio.descripcion),
                    Text('Hora: ${recordatorio.hora.format(context)}'),
                    Text(
                      'Días: ${recordatorio.diasSemana.map((dia) => nombresDiasSemana[dia - 1]).join(', ')}',
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    ),
                  ],
                ),
                trailing: Switch(
                  value: recordatorio.estaActivo,
                  onChanged: (valor) => alAlternarRecordatorio(indice),
                ),
              ),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _mostrarDialogoAgregarRecordatorio(context),
        child: Icon(Icons.add),
        backgroundColor: Colors.black,
      ),
    );
  }

  void _mostrarDialogoAgregarRecordatorio(BuildContext context) {
    String titulo = '';
    String descripcion = '';
    TimeOfDay horaSeleccionada = TimeOfDay.now();
    List<int> diasSemanaSeleccionados = [];

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: Text('Nuevo Recordatorio'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  decoration: InputDecoration(
                    labelText: 'Título del recordatorio',
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (valor) => titulo = valor,
                ),
                SizedBox(height: 16),
                TextField(
                  decoration: InputDecoration(
                    labelText: 'Descripción (opcional)',
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 2,
                  onChanged: (valor) => descripcion = valor,
                ),
                SizedBox(height: 16),
                ListTile(
                  title: Text('Hora del recordatorio'),
                  subtitle: Text(horaSeleccionada.format(context)),
                  trailing: Icon(Icons.access_time),
                  onTap: () async {
                    final hora = await showTimePicker(
                      context: context,
                      initialTime: horaSeleccionada,
                    );
                    if (hora != null) {
                      setState(() {
                        horaSeleccionada = hora;
                      });
                    }
                  },
                ),
                SizedBox(height: 16),
                Text('Días de la semana:', style: TextStyle(fontWeight: FontWeight.bold)),
                Wrap(
                  children: List.generate(7, (indice) {
                    final dia = indice + 1;
                    return Padding(
                      padding: EdgeInsets.symmetric(horizontal: 4),
                      child: FilterChip(
                        label: Text(nombresDiasSemana[indice]),
                        selected: diasSemanaSeleccionados.contains(dia),
                        onSelected: (seleccionado) {
                          setState(() {
                            if (seleccionado) {
                              diasSemanaSeleccionados.add(dia);
                            } else {
                              diasSemanaSeleccionados.remove(dia);
                            }
                          });
                        },
                      ),
                    );
                  }),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: titulo.isNotEmpty && diasSemanaSeleccionados.isNotEmpty
                  ? () {
                alAgregarRecordatorio(Recordatorio(
                  titulo: titulo,
                  descripcion: descripcion,
                  hora: horaSeleccionada,
                  diasSemana: diasSemanaSeleccionados,
                  fechaCreacion: DateTime.now(),
                ));
                Navigator.pop(context);
              }
                  : null,
              child: Text('Crear'),
            ),
          ],
        ),
      ),
    );
  }
}