import 'package:flutter/material.dart';
import 'package:lib/Pantallas/PantallaEstadoAnimo.dart';
import 'package:lib/Pantallas/main.dart';
import 'package:lib/servicios/Autenticacion.dart';

import '../../main.dart';

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final Autenticacion _authService = Autenticacion();
  bool _isLoading = false;
  bool _obscurePassword = true;


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: _emailController,
              decoration: InputDecoration(
                labelText: 'Usuario',
              ),
            ),
            SizedBox(height: 10),
            TextField(
              controller: _passwordController,
              decoration: InputDecoration(
                labelText: 'Contraseña',

                suffixIcon: IconButton(
                  icon: Icon(
                    _obscurePassword ? Icons.visibility_off : Icons.visibility,
                  ),
                  onPressed: () {
                    setState(() {
                      _obscurePassword = !_obscurePassword;
                    });
                  },
                ),
              ),
              obscureText: _obscurePassword,
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _isLoading ? null : () async {
                // Validar campos vacíos
                if (_emailController.text.isEmpty ||
                    _passwordController.text.isEmpty) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Por favor completa todos los campos'),
                      backgroundColor: Colors.red,
                    ),
                  );
                  return;
                }

                setState(() {
                  _isLoading = true;
                });

                // Intentar login
                final resultado = await _authService.login(
                  _emailController.text.trim(),
                  _passwordController.text,
                );

                setState(() {
                  _isLoading = false;
                });

                if (resultado['success']) {
                  // Login exitoso
                  print('🔍 Resultado completo: $resultado');
                  print('🔍 Data: ${resultado['data']}');
                  print('🔍 Usuario: ${resultado['data']['usuario']}');
                  final usuario = resultado['data']['usuario'];

                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('¡Bienvenido ${usuario['nombre']}!'),
                        backgroundColor: Colors.green,
                      ),
                    );

                    // Navegar a PantallaEstadoAnimo
                    final usuarioId = usuario['id'] ?? 1;
                    print('🆔 Usuario ID que se pasa: $usuarioId');
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => PantallaPrincipal (
                          usuarioId: usuarioId,
                        ),
                      ),
                    );
                  }
                } else {
                  // Error en login
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text(resultado['error']),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                }
              },
              child: _isLoading
                  ? const SizedBox(
                height: 20,
                width: 20,
                child: CircularProgressIndicator(
                  color: Colors.white,
                  strokeWidth: 2,
                ),
              )
                  : const Text('Iniciar Sesión'),
            ),
            TextButton(
              onPressed: () {
                // Navegar a la pantalla de registro
                Navigator.pushNamed(context, '/register');
              },
              child: Text('¿No tienes una cuenta? Regístrate'),
            ),
            TextButton(
              onPressed: () {
                // Navegar a la pantalla de registro
                Navigator.pushNamed(context, '/register');
              },
              child: Text('Registrate como psícologo'),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
}