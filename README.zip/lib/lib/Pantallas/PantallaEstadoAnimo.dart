import 'package:flutter/material.dart';
import '../servicios/db_helper.dart';
import '../EstadoAnimo.dart' as estado_model;



class PantallaEstadoAnimo extends StatefulWidget {
  final int usuarioId;

  const PantallaEstadoAnimo({Key? key, required this.usuarioId}) : super(key: key);



  @override
  State<PantallaEstadoAnimo> createState() => _PantallaEstadoAnimoState()
  ;
}

class _PantallaEstadoAnimoState extends State<PantallaEstadoAnimo> {
  final DBHelper _dbHelper = DBHelper();
  List<estado_model.EstadoAnimo> estadosAnimo = [];
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _cargarEstadosAnimo();
  }

  Future<void> _cargarEstadosAnimo() async {
    setState(() => _isLoading = true);

    try {
      final estadosCargados = await _dbHelper.getAllEstadosAnimo(widget.usuarioId);
      setState(() {
        estadosAnimo = estadosCargados;
        _isLoading = false;
      });
    } catch (e) {
      print('Error al cargar estados de ánimo: $e');
      setState(() => _isLoading = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error al cargar estados de ánimo: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  String _colorToString(Color color) {
    return color.toString().split('(0x')[1].split(')')[0];
  }

  Color _stringToColor(String colorString) {
    return Color(int.parse(colorString, radix: 16));
  }

  String _formatearFechaHora(String fecha) {
    try {
      final dt = DateTime.parse(fecha);
      return '${dt.day}/${dt.month}/${dt.year} ${dt.hour}:${dt.minute.toString().padLeft(2, '0')}';
    } catch (e) {
      return fecha;
    }
  }

  void _mostrarDialogoEstadoAnimo(BuildContext context, int nivel, Color color) {
    String nota = '';

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Registrar Estado de Ánimo'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Nivel: $nivel/5'),
            SizedBox(height: 16),
            TextField(
              decoration: InputDecoration(
                labelText: 'Nota (opcional)',
                border: OutlineInputBorder(),
              ),
              maxLines: 3,
              onChanged: (valor) => nota = valor,
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context);

              setState(() => _isLoading = true);

              try {
                final estadoAnimo = estado_model.EstadoAnimo(
                  estado: nivel,
                  comentario: nota,
                  fechaCreacion: DateTime.now(),
                );

                final estadoGuardado = await _dbHelper.insertEstadoAnimo(estadoAnimo, widget.usuarioId);
                
                setState(() => _isLoading = false);

                if (estadoGuardado != null) {
                  setState(() {
                    estadosAnimo.insert(0, estadoGuardado); // Agregar al inicio de la lista
                  });

                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('¡Estado de ánimo guardado!'),
                        backgroundColor: Colors.green,
                      ),
                    );
                  }
                }
              } catch (e) {
                setState(() => _isLoading = false);
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Error al guardar estado de ánimo: $e'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              }
            },
            child: Text('Guardar'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Estado de Ánimo',
          style: TextStyle(fontSize: 24, color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: Colors.black,
      ),
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : Column(
        children: [
          Container(
            padding: EdgeInsets.all(20),
            child: Text(
              '¿Cómo te sientes hoy?',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _construirBotonEstadoAnimo(context, 1, '😢', Colors.red),
              _construirBotonEstadoAnimo(context, 2, '😔', Colors.orange),
              _construirBotonEstadoAnimo(context, 3, '😐', Colors.yellow),
              _construirBotonEstadoAnimo(context, 4, '😊', Colors.lightGreen),
              _construirBotonEstadoAnimo(context, 5, '😄', Colors.green),
            ],
          ),
          SizedBox(height: 20),
          Expanded(
            child: estadosAnimo.isEmpty
                ? Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.mood, size: 80, color: Colors.grey),
                        Text(
                          'No tienes estados de ánimo registrados',
                          style: TextStyle(fontSize: 18, color: Colors.grey),
                        ),
                      ],
                    ),
                  )
                : ListView.builder(
                    itemCount: estadosAnimo.length,
                    itemBuilder: (context, index) {
                      final estado = estadosAnimo[index];
                      return Card(
                        margin: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundColor: estado.getColor().withOpacity(0.2),
                            child: Text(
                              estado.getEmoji(),
                              style: TextStyle(fontSize: 20),
                            ),
                          ),
                          title: Text('Estado: ${estado.estado}/5'),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              if (estado.comentario.isNotEmpty) Text(estado.comentario),
                              Text(
                                'Fecha: ${_formatearFechaHora(estado.fechaCreacion.toIso8601String())}',
                                style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  Widget _construirBotonEstadoAnimo(BuildContext context, int nivel, String emoji, Color color) {
    return GestureDetector(
      onTap: () => _mostrarDialogoEstadoAnimo(context, nivel, color),
      child: Container(
        width: 60,
        height: 60,
        decoration: BoxDecoration(
          color: color.withOpacity(0.2),
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: color, width: 2),
        ),
        child: Center(
          child: Text(
            emoji,
            style: TextStyle(fontSize: 24),
          ),
        ),
      ),
    );
  }
}