import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:lib/Pantallas/PantallaEstadoAnimo.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path/path.dart' as path_package;
import 'package:sqflite/sqflite.dart';
import 'dart:io';
import 'Pantalla_login.dart';
import 'Pantalla_registro.dart';
import 'package:http/http.dart' as http;
import '../Objetivo.dart';
import '../servicios/db_helper.dart';

class PantallaObjetivos extends StatelessWidget {
  final List<Objetivo> objetivos;
  final Function(Objetivo) alAgregarObjetivo;
  final Function(int, Objetivo) alActualizarObjetivo;
  final bool cargando;
  final Future<void> Function()? onRefresh;

  PantallaObjetivos({
    required this.objetivos,
    required this.alAgregarObjetivo,
    required this.alActualizarObjetivo,
    this.cargando = false,
    this.onRefresh,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Mis Objetivos',
            style: TextStyle(fontSize: 24, color: Colors.white , fontWeight: FontWeight.bold)  ),
        backgroundColor: Colors.black,
        actions: [
          IconButton(
            icon: Icon(Icons.bug_report),
            onPressed: () {
              print('🐛 DEBUG - Objetivos en pantalla: ${objetivos.length}');
              for (var obj in objetivos) {
                print('  - ${obj.titulo} (ID: ${obj.id})');
              }
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Debug: ${objetivos.length} objetivos en pantalla')),
              );
            },
          ),
          IconButton(
            icon: Icon(Icons.refresh),
            onPressed: () {
              print('🔄 Forzando recarga de objetivos...');
              onRefresh?.call();
            },
          ),
        ],
      ),
      body: cargando
          ? Center(child: CircularProgressIndicator())
          : objetivos.isEmpty
              ? Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.flag, size: 80, color: Colors.grey),
            Text(
              'No tienes objetivos aún',
              style: TextStyle(fontSize: 18, color: Colors.grey),
            ),
          ],
        ),
      )
              : RefreshIndicator(
        onRefresh: onRefresh ?? () async {},
        child: ListView.builder(
          itemCount: objetivos.length,
          itemBuilder: (context, indice) {
            final objetivo = objetivos[indice];
            return Card(
              margin: EdgeInsets.symmetric(horizontal: 16, vertical: 4),
              child: ListTile(
                leading: Checkbox(
                  value: objetivo.estaCompletado,
                  onChanged: (valor) {
                    alActualizarObjetivo(
                      indice,
                      Objetivo(
                        titulo: objetivo.titulo,
                        descripcion: objetivo.descripcion,
                        fechaObjetivo: objetivo.fechaObjetivo,
                        horaObjetivo: objetivo.horaObjetivo,
                        estaCompletado: valor ?? false,
                        fechaCreacion: objetivo.fechaCreacion,
                      ),
                    );
                  },
                ),
                title: Text(
                  objetivo.titulo,
                  style: TextStyle(
                    decoration: objetivo.estaCompletado
                        ? TextDecoration.lineThrough
                        : TextDecoration.none,
                  ),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (objetivo.descripcion.isNotEmpty) Text(objetivo.descripcion),
                    Text(
                      'Fecha: ${_formatearFecha(objetivo.fechaObjetivo)} a las ${objetivo.horaObjetivo.format(context)}',
                      style: TextStyle(fontSize: 12, color: Colors.grey[600]),
                    ),
                  ],
                ),
                trailing: Icon(
                  objetivo.estaCompletado ? Icons.check_circle : Icons.radio_button_unchecked,
                  color: objetivo.estaCompletado ? Colors.green : Colors.grey,
                ),
              ),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _mostrarDialogoAgregarObjetivo(context),
        child: Icon(Icons.add),
        backgroundColor: Colors.black,
      ),
    );
  }

  void _mostrarDialogoAgregarObjetivo(BuildContext context) {
    String titulo = '';
    String descripcion = '';
    DateTime fechaSeleccionada = DateTime.now();
    TimeOfDay horaSeleccionada = TimeOfDay.now();

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: Text('Nuevo Objetivo'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  decoration: InputDecoration(
                    labelText: 'Título del objetivo',
                    border: OutlineInputBorder(),
                  ),
                  onChanged: (valor) => titulo = valor,
                ),
                SizedBox(height: 16),
                TextField(
                  decoration: InputDecoration(
                    labelText: 'Descripción (opcional)',
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 2,
                  onChanged: (valor) => descripcion = valor,
                ),
                SizedBox(height: 16),
                ListTile(
                  title: Text('Fecha objetivo'),
                  subtitle: Text(_formatearFecha(fechaSeleccionada)),
                  trailing: Icon(Icons.calendar_today),
                  onTap: () async {
                    final fecha = await showDatePicker(
                      context: context,
                      initialDate: fechaSeleccionada,
                      firstDate: DateTime.now(),
                      lastDate: DateTime.now().add(Duration(days: 365)),
                    );
                    if (fecha != null) {
                      setState(() {
                        fechaSeleccionada = fecha;
                      });
                    }
                  },
                ),
                ListTile(
                  title: Text('Hora objetivo'),
                  subtitle: Text(horaSeleccionada.format(context)),
                  trailing: Icon(Icons.access_time),
                  onTap: () async {
                    final hora = await showTimePicker(
                      context: context,
                      initialTime: horaSeleccionada,
                    );
                    if (hora != null) {
                      setState(() {
                        horaSeleccionada = hora;
                      });
                    }
                  },
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: titulo.isNotEmpty
                  ? () {
                alAgregarObjetivo(Objetivo(
                  titulo: titulo,
                  descripcion: descripcion,
                  fechaObjetivo: fechaSeleccionada,
                  horaObjetivo: horaSeleccionada,
                  fechaCreacion: DateTime.now(),
                ));
                Navigator.pop(context);
              }
                  : null,
              child: Text('Crear'),
            ),
          ],
        ),
      ),
    );
  }

  String _formatearFecha(DateTime fecha) {
    return '${fecha.day.toString().padLeft(2, '0')}/${fecha.month.toString().padLeft(2, '0')}/${fecha.year}';
  }
}