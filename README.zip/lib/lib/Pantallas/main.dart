import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:lib/Pantallas/PantallaEstadoAnimo.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path/path.dart' as path_package;
import 'package:sqflite/sqflite.dart';
import 'dart:io';
import 'Pantalla_login.dart';
import 'Pantalla_registro.dart';
import 'package:http/http.dart' as http;
import 'Pantalla_Objetivos.dart';
import 'Pantalla_Recordatorios.dart';
import '../Objetivo.dart' as objetivo_model;
import '../Recordatorio.dart' as recordatorio_model;
import '../servicios/db_helper.dart';

void main() {
  runApp(AplicacionBienestar());
}

class AplicacionBienestar extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mi Bienestar',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      initialRoute: '/', // Define la ruta inicial de la aplicación
      routes: {
        '/': (context) => LoginPage(),
        '/register': (context) => RegisterPage(),

      },
    );
  }
}

class PantallaPrincipal extends StatefulWidget {
  final int usuarioId;

  const PantallaPrincipal({Key? key, required this.usuarioId}) : super(key: key);

  @override
  _EstadoPantallaPrincipal createState() => _EstadoPantallaPrincipal();
}

class _EstadoPantallaPrincipal extends State<PantallaPrincipal> {
  int _indiceSeleccionado = 0;
  List<objetivo_model.Objetivo> objetivos = [];
  List<recordatorio_model.Recordatorio> recordatorios = [];
  final DBHelper _dbHelper = DBHelper();
  bool _cargandoObjetivos = false;
  bool _cargandoRecordatorios = false;

  @override
  void initState() {
    super.initState();
    _cargarObjetivos();
    _cargarRecordatorios();
  }

  Future<void> _cargarObjetivos() async {
    print('🔄 Iniciando carga de objetivos para usuario: ${widget.usuarioId}');
    setState(() {
      _cargandoObjetivos = true;
    });

    try {
      final objetivosCargados = await _dbHelper.getAllObjetivos(widget.usuarioId);
      print('📥 Objetivos cargados: ${objetivosCargados.length}');
      for (var obj in objetivosCargados) {
        print('  - ${obj.titulo} (ID: ${obj.id})');
      }
      setState(() {
        objetivos = objetivosCargados;
        _cargandoObjetivos = false;
      });
      print('✅ Lista de objetivos actualizada: ${objetivos.length} elementos');
    } catch (e) {
      print('❌ Error al cargar objetivos: $e');
      setState(() {
        _cargandoObjetivos = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al cargar objetivos: $e')),
      );
    }
  }

  Future<void> _agregarObjetivo(objetivo_model.Objetivo objetivo) async {
    print('🎯 Intentando guardar objetivo: ${objetivo.titulo}');
    print('🆔 Usuario ID para insertar: ${widget.usuarioId}');
    try {
      final objetivoGuardado = await _dbHelper.insertObjetivo(objetivo, widget.usuarioId);
      print('📥 Respuesta del servidor: $objetivoGuardado');
      
      if (objetivoGuardado != null) {
        setState(() {
          objetivos.add(objetivoGuardado);
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('✅ Objetivo guardado correctamente')),
        );
        print('✅ Objetivo guardado exitosamente');
      } else {
        print('❌ El servidor devolvió null');
        throw Exception('El servidor no pudo guardar el objetivo');
      }
    } catch (e) {
      print('❌ Error completo al guardar objetivo: $e');
      print('❌ Tipo de error: ${e.runtimeType}');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('❌ Error al guardar: ${e.toString()}'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 5),
        ),
      );
    }
  }

  Future<void> _actualizarObjetivo(int indice, objetivo_model.Objetivo objetivo) async {
    try {
      final exito = await _dbHelper.updateObjetivo(objetivo);
      if (exito) {
        setState(() {
          objetivos[indice] = objetivo;
        });
      } else {
        throw Exception('No se pudo actualizar el objetivo');
      }
    } catch (e) {
      print('Error al actualizar objetivo: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al actualizar objetivo: $e')),
      );
    }
  }

  Future<void> _cargarRecordatorios() async {
    setState(() {
      _cargandoRecordatorios = true;
    });

    try {
      final recordatoriosCargados = await _dbHelper.getAllRecordatorios(widget.usuarioId);
      setState(() {
        recordatorios = recordatoriosCargados;
        _cargandoRecordatorios = false;
      });
    } catch (e) {
      print('Error al cargar recordatorios: $e');
      setState(() {
        _cargandoRecordatorios = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al cargar recordatorios: $e')),
      );
    }
  }

  Future<void> _agregarRecordatorio(recordatorio_model.Recordatorio recordatorio) async {
    print('🔔 Intentando guardar recordatorio: ${recordatorio.titulo}');
    print('🆔 Usuario ID para insertar: ${widget.usuarioId}');
    try {
      final recordatorioGuardado = await _dbHelper.insertRecordatorio(recordatorio, widget.usuarioId);
      print('📥 Respuesta del servidor: $recordatorioGuardado');
      
      if (recordatorioGuardado != null) {
        setState(() {
          recordatorios.add(recordatorioGuardado);
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('✅ Recordatorio guardado correctamente')),
        );
        print('✅ Recordatorio guardado exitosamente');
      } else {
        print('❌ El servidor devolvió null');
        throw Exception('El servidor no pudo guardar el recordatorio');
      }
    } catch (e) {
      print('❌ Error completo al guardar recordatorio: $e');
      print('❌ Tipo de error: ${e.runtimeType}');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('❌ Error al guardar: ${e.toString()}'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 5),
        ),
      );
    }
  }

  Future<void> _actualizarRecordatorio(int indice, recordatorio_model.Recordatorio recordatorio) async {
    try {
      final exito = await _dbHelper.updateRecordatorio(recordatorio);
      if (exito) {
        setState(() {
          recordatorios[indice] = recordatorio;
        });
      } else {
        throw Exception('No se pudo actualizar el recordatorio');
      }
    } catch (e) {
      print('Error al actualizar recordatorio: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error al actualizar recordatorio: $e')),
      );
    }
  }

  Widget _getCurrentPage() {
    print('📱 Construyendo página para índice: $_indiceSeleccionado');
    print('📊 Objetivos disponibles: ${objetivos.length}');
    print('📊 Recordatorios disponibles: ${recordatorios.length}');
    
    switch (_indiceSeleccionado) {
      case 0:
        return PantallaEstadoAnimo(usuarioId: widget.usuarioId);
      case 1:
        return PantallaObjetivos(
          objetivos: objetivos,
          alAgregarObjetivo: _agregarObjetivo,
          alActualizarObjetivo: _actualizarObjetivo,
          cargando: _cargandoObjetivos,
          onRefresh: _cargarObjetivos,
        );
      case 2:
        return PantallaRecordatorios(
          recordatorios: recordatorios,
          alAgregarRecordatorio: _agregarRecordatorio,
          alAlternarRecordatorio: (indice) {
            final recordatorio = recordatorios[indice];
            final recordatorioActualizado = recordatorio_model.Recordatorio(
              id: recordatorio.id,
              titulo: recordatorio.titulo,
              descripcion: recordatorio.descripcion,
              hora: recordatorio.hora,
              diasSemana: recordatorio.diasSemana,
              estaActivo: !recordatorio.estaActivo,
              fechaCreacion: recordatorio.fechaCreacion,
            );
            _actualizarRecordatorio(indice, recordatorioActualizado);
          },
          cargando: _cargandoRecordatorios,
          onRefresh: _cargarRecordatorios,
        );
      case 3:
        return PantallaTabla();
      default:
        return PantallaEstadoAnimo(usuarioId: widget.usuarioId);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _getCurrentPage(),
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _indiceSeleccionado,
        onTap: (indice) async {
          setState(() {
            _indiceSeleccionado = indice;
          });
          if (indice == 1) {
            await _cargarObjetivos();
          } else if (indice == 2) {
            await _cargarRecordatorios();
          }
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.mood),
            label: 'Estado de Ánimo',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.flag),
            label: 'Objetivos',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.notifications),
            label: 'Recordatorios',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.table_chart),
            label: 'Psicologos',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.table_chart),
            label: 'Registro de estados',
          ),
        ],
      ),
    );
  }
}
class EntradaEstadoAnimo {
  final DateTime fecha;
  final int nivelEstadoAnimo;
  final String nota;
  final Color color;

  EntradaEstadoAnimo({
    required this.fecha,
    required this.nivelEstadoAnimo,
    required this.nota,
    required this.color,
  });
}

class Registro {
  final int codigo;
  final String nombre;
  final String especialidad;
  final String nro_registro;

  Registro({
    required this.codigo,
    required this.nombre,
    required this.especialidad,
    required this.nro_registro,
  });

  factory Registro.fromJson(Map<String, dynamic> json) {
    return Registro(
      codigo: json['codigo'] ?? 1,
      nombre: json['nombre'] ?? '',
      especialidad: json['especialidad'] ?? '',
      nro_registro: json['nro_registro'] ?? '',
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'codigo': codigo,
      'nombre': nombre,
      'especialidad': especialidad,
      'nro_registro': nro_registro,
    };
  }
}

class RegistroService {
  static const String baseUrl = 'http://localhost:3000/api';

  static Future<List<Registro>> obtenerRegistros() async {
    try {
      print('🔄 Obteniendo registros de: $baseUrl/registros');

      final response = await http.get(
        Uri.parse('$baseUrl/registros'),
        headers: {
          'Content-Type': 'application/json',
        },
      ).timeout(Duration(seconds: 10));

      print('📡 Respuesta del servidor: ${response.statusCode}');

      if (response.statusCode == 200) {
        List<dynamic> jsonList = json.decode(response.body);
        List<Registro> registros = jsonList.map((json) => Registro.fromJson(json)).toList();

        print('✅ ${registros.length} registros obtenidos exitosamente');
        return registros;
      } else {
        throw Exception('Error del servidor: ${response.statusCode}');
      }
    } catch (e) {
      print('❌ Error al obtener registros: $e');
      throw Exception('Error de conexión: $e');
    }
  }

  static Future<Registro> crearRegistro(int codigo, String nombre, String especialidad, String nroRegistro) async {
    try {
      print('➕ Creando registro: $nombre');

      final response = await http.post(
        Uri.parse('$baseUrl/registros'),
        headers: {
          'Content-Type': 'application/json',
        },
        body: json.encode({
          'codigo': codigo,
          'nombre': nombre,
          'especialidad': especialidad,
          'nro_registro': nroRegistro,
        }),
      ).timeout(Duration(seconds: 10));

      if (response.statusCode == 201) {
        final registroCreado = Registro.fromJson(json.decode(response.body));
        print('✅ Registro creado con número: ${registroCreado.codigo}');
        return registroCreado;
      } else {
        throw Exception('Error al crear registro');
      }
    } catch (e) {
      print('❌ Error al crear registro: $e');
      throw Exception('Error al crear registro: $e');
    }
  }

  static Future<void> eliminarRegistro(int nroSocio) async {
    try {
      print('🗑️ Eliminando registro número: $nroSocio');

      final response = await http.delete(
        Uri.parse('$baseUrl/registros/$nroSocio'),
        headers: {
          'Content-Type': 'application/json',
        },
      ).timeout(Duration(seconds: 10));

      if (response.statusCode != 200) {
        throw Exception('Error al eliminar registro');
      }

      print('✅ Registro eliminado exitosamente');
    } catch (e) {
      print('❌ Error al eliminar registro: $e');
      throw Exception('Error al eliminar registro: $e');
    }
  }
}


class PantallaTabla extends StatefulWidget {
  @override
  _PantallaTablaState createState() => _PantallaTablaState();
}

class _PantallaTablaState extends State<PantallaTabla> {
  List<Registro> registros = [];
  bool isLoading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    cargarDatos();
  }

  Future<void> cargarDatos() async {
    try {
      setState(() {
        isLoading = true;
        error = null;
      });

      final datos = await RegistroService.obtenerRegistros();

      setState(() {
        registros = datos;
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        error = e.toString();
        isLoading = false;
      });
    }
  }

  void mostrarDialogoAgregar() {
    final nroSocioController = TextEditingController();
    final nombreController = TextEditingController();
    final especialidadController = TextEditingController();
    final nroRegistroController = TextEditingController();

    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text('Agregar Registro'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nroSocioController,
                  decoration: InputDecoration(
                    labelText: 'Número de Socio',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.numbers),
                  ),
                  keyboardType: TextInputType.number,
                ),
                SizedBox(height: 16),
                TextField(
                  controller: nombreController,
                  decoration: InputDecoration(
                    labelText: 'Nombre',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.person),
                  ),
                ),
                SizedBox(height: 16),
                TextField(
                  controller: especialidadController,
                  decoration: InputDecoration(
                    labelText: 'Área',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.business),
                  ),
                ),
                SizedBox(height: 16),
                TextField(
                  controller: nroRegistroController,
                  decoration: InputDecoration(
                    labelText: 'Número de Registro',
                    border: OutlineInputBorder(),
                    prefixIcon: Icon(Icons.assignment),
                  ),
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () async {
                if (nroSocioController.text.trim().isNotEmpty &&
                    nombreController.text.trim().isNotEmpty) {
                  try {
                    await RegistroService.crearRegistro(
                      int.parse(nroSocioController.text.trim()),
                      nombreController.text.trim(),
                      especialidadController.text.trim(),
                      nroRegistroController.text.trim(),
                    );
                    Navigator.of(dialogContext).pop();
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('✅ Registro creado exitosamente'),
                        backgroundColor: Colors.green,
                      ),
                    );
                    cargarDatos();
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('❌ Error: $e'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                }
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
              child: Text('Agregar', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

  void confirmarEliminar(Registro registro) {
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: Text('Confirmar eliminación'),
          content: Text('¿Estás seguro de que deseas eliminar "${registro.nombre}"?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () async {
                Navigator.of(dialogContext).pop();
                try {
                  // CORREGIDO: Usar codigo en lugar de id
                  await RegistroService.eliminarRegistro(registro.codigo);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('✅ Registro eliminado'),
                      backgroundColor: Colors.green,
                    ),
                  );
                  cargarDatos();
                } catch (e) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('❌ Error: $e'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              child: Text('Eliminar', style: TextStyle(color: Colors.white)),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Registro',
          style: TextStyle(
            fontSize: 24,
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.black,
        actions: [
          IconButton(
            icon: Icon(Icons.add, color: Colors.white),
            onPressed: mostrarDialogoAgregar,
          ),
          IconButton(
            icon: Icon(Icons.refresh, color: Colors.white),
            onPressed: cargarDatos,
          ),
        ],
      ),
      body: Column(
        children: [
          Container(
            padding: EdgeInsets.all(16),
            child: Row(
              children: [
                Icon(Icons.table_chart, size: 32, color: Colors.orange),
                SizedBox(width: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Registro de Estado',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      isLoading
                          ? 'Cargando...'
                          : 'Total: ${registros.length} registros',
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: _buildContent(),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: mostrarDialogoAgregar,
        backgroundColor: Colors.orange,
        child: Icon(Icons.add, color: Colors.white),
      ),
    );
  }

  Widget _buildContent() {
    if (isLoading) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(color: Colors.orange),
            SizedBox(height: 16),
            Text('Conectando con PostgreSQL...'),
          ],
        ),
      );
    }

    if (error != null) {
      return Center(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.error_outline, size: 64, color: Colors.red),
              SizedBox(height: 16),
              Text(
                'Error de conexión',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 8),
              Text(
                error!,
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey[600]),
              ),
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: cargarDatos,
                style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                child: Text('Reintentar', style: TextStyle(color: Colors.white)),
              ),
            ],
          ),
        ),
      );
    }

    if (registros.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inbox, size: 64, color: Colors.grey),
            SizedBox(height: 16),
            Text(
              'No hay registros disponibles',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 8),
            Text(
              'Presiona + para agregar el primero',
              style: TextStyle(color: Colors.grey[600]),
            ),
          ],
        ),
      );
    }

    return SingleChildScrollView(
      padding: EdgeInsets.all(16),
      child: Card(
        elevation: 4,
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: DataTable(
            headingRowColor: MaterialStateProperty.all(Colors.grey[100]),
            columns: [
              DataColumn(
                label: Text(
                  'Nro Socio',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              DataColumn(
                label: Text(
                  'Nombre',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              DataColumn(
                label: Text(
                  'Área',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              DataColumn(
                label: Text(
                  'Nro Registro',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
              DataColumn(
                label: Text(
                  'Acciones',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
              ),
            ],
            rows: registros.map((registro) {
              return DataRow(
                cells: [
                  // CORREGIDO: Usar las propiedades correctas
                  DataCell(Text(registro.codigo.toString())),
                  DataCell(Text(registro.nombre)),
                  DataCell(Text(registro.especialidad)),
                  DataCell(Text(registro.nro_registro)),
                  DataCell(
                    IconButton(
                      icon: Icon(Icons.delete, color: Colors.red),
                      onPressed: () => confirmarEliminar(registro),
                    ),
                  ),
                ],
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}