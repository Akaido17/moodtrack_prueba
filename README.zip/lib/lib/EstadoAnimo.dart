import 'package:flutter/material.dart';

class EstadoAnimo {
  int? id;
  int? idUsuario;
  final int estado;
  final String comentario;
  final DateTime fechaCreacion;

  EstadoAnimo({
    this.id,
    this.idUsuario,
    required this.estado,
    required this.comentario,
    required this.fechaCreacion,
  });


  Map<String, dynamic> toJson() {
    return {
      if (id != null) 'id': id,
      if (idUsuario != null) 'id_usuario': idUsuario,
      'estado': estado,
      'comentario': comentario,
      'fecha_creacion': fechaCreacion.toIso8601String(),
    };
  }


  factory EstadoAnimo.fromJson(Map<String, dynamic> json) {
    return EstadoAnimo(
      id: json['id'],
      idUsuario: json['id_usuario'],
      estado: json['estado'] ?? 0,
      comentario: json['comentario'] ?? '',
      fechaCreacion: DateTime.parse(json['fecha_creacion']),
    );
  }


  Color getColor() {
    switch (estado) {
      case 1:
        return Colors.red;
      case 2:
        return Colors.orange;
      case 3:
        return Colors.yellow;
      case 4:
        return Colors.lightGreen;
      case 5:
        return Colors.green;
      default:
        return Colors.grey;
    }
  }


  String getEmoji() {
    switch (estado) {
      case 1:
        return '😢';
      case 2:
        return '😔';
      case 3:
        return '😐';
      case 4:
        return '😊';
      case 5:
        return '😄';
      default:
        return '😶';
    }
  }
}


