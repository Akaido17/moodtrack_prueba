import 'dart:convert';
import 'package:http/http.dart' as http;

class Guardar_Estado {
  static const String baseUrl = 'http://localhost:3000/api';

  Future<Map<String, dynamic>> guardarEstadoAnimo({
    required int usuarioId,
    required int estado,
    required String nota,
  }) async {
    print('💾 Guardando estado de ánimo...');

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/estados-animo'),
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
        },
        body: jsonEncode({
          'codigo': usuarioId,
          'estado': estado,
          'comentario': nota,
        }),
      );

      print('📥 Status: ${response.statusCode}');
      print('📥 Body: ${response.body}');

      if (response.statusCode == 201) {
        return {
          'success': true,
          'data': jsonDecode(response.body),
        };
      } else {
        return {
          'success': false,
          'error': 'Error al guardar',
        };
      }
    } catch (e) {
      print('❌ Error: $e');
      return {
        'success': false,
        'error': 'Error de conexión: $e',
      };
    }
  }

  Future<Map<String, dynamic>> obtenerEstadosAnimo(int usuarioId) async {
    print('📋 Obteniendo estados de ánimo...');

    try {
      final response = await http.get(
        Uri.parse('$baseUrl/estados-animo/$usuarioId'),
        headers: {'Accept': 'application/json'},
      );

      if (response.statusCode == 200) {
        return {
          'success': true,
          'data': jsonDecode(response.body)['data'],
        };
      } else {
        return {
          'success': false,
          'error': 'Error al obtener datos',
        };
      }
    } catch (e) {
      print('❌ Error: $e');
      return {
        'success': false,
        'error': 'Error de conexión: $e',
      };
    }
  }
}