import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:flutter/material.dart';
import '../Objetivo.dart'; // Asegúrate de importar tu clase Objetivo
import '../Recordatorio.dart'; // Importar clase Recordatorio
import '../EstadoAnimo.dart'; // Importar clase EstadoAnimo

class DBHelper {
  static final DBHelper _instance = DBHelper._internal();
  factory DBHelper() => _instance;
  DBHelper._internal();

  static const String baseUrl = 'http://localhost:3000/api';

  Future<List<Objetivo>> getAllObjetivos(int usuarioId) async {
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/metas/usuario/$usuarioId'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        print('🎯 Datos recibidos de la API: ${data.length} elementos');
        if (data.isNotEmpty) {
          print('🎯 Primer elemento: ${data[0]}');
        }
        final objetivos = data.map((json) => Objetivo.fromJson(json)).toList();
        print('🎯 Objetivos parseados: ${objetivos.length}');
        return objetivos;
      } else {
        throw Exception('Error al cargar objetivos: ${response.statusCode}');
      }
    } catch (e) {
      print('Error en getAllObjetivos: $e');
      return []; // Retorna lista vacía en caso de error
    }
  }

  Future<Objetivo?> insertObjetivo(Objetivo objetivo, int usuarioId) async {
    print('📤 Enviando POST a: $baseUrl/metas');
    final body = objetivo.toJson();
    print('📦 Datos a enviar: $body');
    
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/metas'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(body),
      );

      print('📥 Status Code: ${response.statusCode}');
      print('📥 Response Body: ${response.body}');
      print('📥 Response Headers: ${response.headers}');

      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = json.decode(response.body);
        print('✅ Datos parseados: $data');
        return Objetivo.fromJson(data);
      } else {
        print('❌ Error HTTP: ${response.statusCode} - ${response.body}');
        throw Exception('Error al crear objetivo: ${response.statusCode} - ${response.body}');
      }
    } catch (e) {
      print('❌ Error completo en insertObjetivo: $e');
      print('❌ Tipo de error: ${e.runtimeType}');
      rethrow; // Re-lanzar el error para que se maneje en main.dart
    }
  }

  Future<bool> updateObjetivo(Objetivo objetivo) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/metas/${objetivo.id}'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(objetivo.toJson()),
      );

      if (response.statusCode == 200) {
        return true;
      } else {
        throw Exception('Error al actualizar objetivo: ${response.statusCode}');
      }
    } catch (e) {
      print('Error en updateObjetivo: $e');
      return false;
    }
  }

  Future<bool> deleteObjetivo(int id) async {
    try {
      final response = await http.delete(
        Uri.parse('$baseUrl/metas/$id'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        return true;
      } else {
        throw Exception('Error al eliminar objetivo: ${response.statusCode}');
      }
    } catch (e) {
      print('Error en deleteObjetivo: $e');
      return false;
    }
  }

  // ==================== MÉTODOS PARA RECORDATORIOS ====================

  Future<List<Recordatorio>> getAllRecordatorios(int usuarioId) async {
    print('🔔 Obteniendo todos los recordatorios...');
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/recordatorios/usuario/$usuarioId'),
        headers: {'Content-Type': 'application/json'},
      );

      print('📥 Status Code: ${response.statusCode}');
      print('📥 Response Body: ${response.body}');

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        return data.map((json) => Recordatorio.fromJson(json)).toList();
      } else {
        throw Exception('Error al cargar recordatorios: ${response.statusCode}');
      }
    } catch (e) {
      print('Error en getAllRecordatorios: $e');
      return []; // Retorna lista vacía en caso de error
    }
  }

  Future<Recordatorio?> insertRecordatorio(Recordatorio recordatorio, int usuarioId) async {
    print('📤 Enviando POST a: $baseUrl/recordatorios');
    final body = {
      ...recordatorio.toJson(),
      'id_usuario': usuarioId,
    };
    print('📦 Datos a enviar: $body');
    
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/recordatorios'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(body),
      );

      print('📥 Status Code: ${response.statusCode}');
      print('📥 Response Body: ${response.body}');
      print('📥 Response Headers: ${response.headers}');

      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = json.decode(response.body);
        print('✅ Datos parseados: $data');
        return Recordatorio.fromJson(data);
      } else {
        print('❌ Error HTTP: ${response.statusCode} - ${response.body}');
        throw Exception('Error al crear recordatorio: ${response.statusCode} - ${response.body}');
      }
    } catch (e) {
      print('❌ Error completo en insertRecordatorio: $e');
      print('❌ Tipo de error: ${e.runtimeType}');
      rethrow; // Re-lanzar el error para que se maneje en main.dart
    }
  }

  Future<bool> updateRecordatorio(Recordatorio recordatorio) async {
    try {
      final response = await http.put(
        Uri.parse('$baseUrl/recordatorios/${recordatorio.id}'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(recordatorio.toJson()),
      );

      if (response.statusCode == 200) {
        return true;
      } else {
        throw Exception('Error al actualizar recordatorio: ${response.statusCode}');
      }
    } catch (e) {
      print('Error en updateRecordatorio: $e');
      return false;
    }
  }

  Future<bool> deleteRecordatorio(int id) async {
    try {
      final response = await http.delete(
        Uri.parse('$baseUrl/recordatorios/$id'),
        headers: {'Content-Type': 'application/json'},
      );

      if (response.statusCode == 200) {
        return true;
      } else {
        throw Exception('Error al eliminar recordatorio: ${response.statusCode}');
      }
    } catch (e) {
      print('Error en deleteRecordatorio: $e');
      return false;
    }
  }

  // ==================== MÉTODOS PARA ESTADOS DE ÁNIMO ====================

  Future<List<EstadoAnimo>> getAllEstadosAnimo(int usuarioId) async {
    print('💭 Obteniendo todos los estados de ánimo...');
    try {
      final response = await http.get(
        Uri.parse('$baseUrl/estados-animo/usuario/$usuarioId'),
        headers: {'Content-Type': 'application/json'},
      );

      print('📥 Status Code: ${response.statusCode}');
      print('📥 Response Body: ${response.body}');

      if (response.statusCode == 200) {
        final List<dynamic> data = json.decode(response.body);
        return data.map((json) => EstadoAnimo.fromJson(json)).toList();
      } else {
        throw Exception('Error al cargar estados de ánimo: ${response.statusCode}');
      }
    } catch (e) {
      print('Error en getAllEstadosAnimo: $e');
      return []; // Retorna lista vacía en caso de error
    }
  }

  Future<EstadoAnimo?> insertEstadoAnimo(EstadoAnimo estadoAnimo, int usuarioId) async {
    print('📤 Enviando POST a: $baseUrl/estados-animo');
    final body = {
      ...estadoAnimo.toJson(),
      'id_usuario': usuarioId,
    };
    print('📦 Datos a enviar: $body');
    
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/estados-animo'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode(body),
      );

      print('📥 Status Code: ${response.statusCode}');
      print('📥 Response Body: ${response.body}');
      print('📥 Response Headers: ${response.headers}');

      if (response.statusCode == 200 || response.statusCode == 201) {
        final data = json.decode(response.body);
        print('✅ Datos parseados: $data');
        return EstadoAnimo.fromJson(data);
      } else {
        print('❌ Error HTTP: ${response.statusCode} - ${response.body}');
        throw Exception('Error al crear estado de ánimo: ${response.statusCode} - ${response.body}');
      }
    } catch (e) {
      print('❌ Error completo en insertEstadoAnimo: $e');
      print('❌ Tipo de error: ${e.runtimeType}');
      rethrow; // Re-lanzar el error para que se maneje en main.dart
    }
  }
}
